<?php
// Configuration package used
define('CONFIG_PACK', 'pre_10');


// Package directory (do not change)
define('PACK_DIR', dirname(__FILE__) . '/packs/');
